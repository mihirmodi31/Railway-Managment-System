-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 03, 2021 at 09:48 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ce73`
--

-- --------------------------------------------------------

--
-- Table structure for table `auth_group`
--

CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `auth_group_permissions`
--

CREATE TABLE `auth_group_permissions` (
  `id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `auth_permission`
--

CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `auth_permission`
--

INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES
(1, 'Can add log entry', 1, 'add_logentry'),
(2, 'Can change log entry', 1, 'change_logentry'),
(3, 'Can delete log entry', 1, 'delete_logentry'),
(4, 'Can view log entry', 1, 'view_logentry'),
(5, 'Can add permission', 2, 'add_permission'),
(6, 'Can change permission', 2, 'change_permission'),
(7, 'Can delete permission', 2, 'delete_permission'),
(8, 'Can view permission', 2, 'view_permission'),
(9, 'Can add group', 3, 'add_group'),
(10, 'Can change group', 3, 'change_group'),
(11, 'Can delete group', 3, 'delete_group'),
(12, 'Can view group', 3, 'view_group'),
(13, 'Can add user', 4, 'add_user'),
(14, 'Can change user', 4, 'change_user'),
(15, 'Can delete user', 4, 'delete_user'),
(16, 'Can view user', 4, 'view_user'),
(17, 'Can add content type', 5, 'add_contenttype'),
(18, 'Can change content type', 5, 'change_contenttype'),
(19, 'Can delete content type', 5, 'delete_contenttype'),
(20, 'Can view content type', 5, 'view_contenttype'),
(21, 'Can add session', 6, 'add_session'),
(22, 'Can change session', 6, 'change_session'),
(23, 'Can delete session', 6, 'delete_session'),
(24, 'Can view session', 6, 'view_session'),
(25, 'Can add student', 7, 'add_student'),
(26, 'Can change student', 7, 'change_student'),
(27, 'Can delete student', 7, 'delete_student'),
(28, 'Can view student', 7, 'view_student'),
(29, 'Can add trains', 8, 'add_trains'),
(30, 'Can change trains', 8, 'change_trains'),
(31, 'Can delete trains', 8, 'delete_trains'),
(32, 'Can view trains', 8, 'view_trains'),
(33, 'Can add tickets', 9, 'add_tickets'),
(34, 'Can change tickets', 9, 'change_tickets'),
(35, 'Can delete tickets', 9, 'delete_tickets'),
(36, 'Can view tickets', 9, 'view_tickets'),
(37, 'Can add avail', 10, 'add_avail'),
(38, 'Can change avail', 10, 'change_avail'),
(39, 'Can delete avail', 10, 'delete_avail'),
(40, 'Can view avail', 10, 'view_avail'),
(41, 'Can add feedback', 11, 'add_feedback'),
(42, 'Can change feedback', 11, 'change_feedback'),
(43, 'Can delete feedback', 11, 'delete_feedback'),
(44, 'Can view feedback', 11, 'view_feedback');

-- --------------------------------------------------------

--
-- Table structure for table `auth_user`
--

CREATE TABLE `auth_user` (
  `id` int(11) NOT NULL,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `auth_user`
--

INSERT INTO `auth_user` (`id`, `password`, `last_login`, `is_superuser`, `username`, `first_name`, `last_name`, `email`, `is_staff`, `is_active`, `date_joined`) VALUES
(1, 'pbkdf2_sha256$216000$bM45QUCYDb1T$8k8ALbGyag5uHho33V214y4pHLBGMbjIiqvf5Ufymxo=', '2021-04-03 07:34:59.190589', 1, 'morkerdeep11', '', '', 'morkerdeep11@gmail.com', 1, 1, '2021-03-04 10:31:38.566325'),
(4, 'pbkdf2_sha256$216000$mwbzynoc3d0G$vIoIcf59E8hQWrnAb1AkWrYa47F74J0LrRlXN44uElQ=', '2021-03-10 12:17:26.770909', 0, 'user1', 'abc', 'xyz', 'user1@gmail.com', 0, 1, '2021-03-10 12:17:14.452120'),
(5, 'pbkdf2_sha256$216000$5L2yJaqpmAL6$4sr2gKzA8iiYizG+iC8fMJKJ6o1x2bps+p9etaSqKAc=', '2021-03-13 10:35:00.964516', 0, 'ce073', 'ce073', 'ce073', 'ce073@temp.com', 0, 1, '2021-03-13 06:41:07.055877'),
(6, 'pbkdf2_sha256$216000$zPlPgI274T1G$qUrTiqY3miqxCv2NdV+BtIR5rlqhw6hRIhIh8EAmLkE=', '2021-03-19 10:22:06.830867', 0, 'ab11', 'abc', 'pqr', 'fag@g.com', 0, 1, '2021-03-19 10:21:51.855561');

-- --------------------------------------------------------

--
-- Table structure for table `auth_user_groups`
--

CREATE TABLE `auth_user_groups` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `auth_user_user_permissions`
--

CREATE TABLE `auth_user_user_permissions` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `dbtestapp_student`
--

CREATE TABLE `dbtestapp_student` (
  `id` int(11) NOT NULL,
  `student_name` varchar(100) NOT NULL,
  `student_dob` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `display_trains`
--

CREATE TABLE `display_trains` (
  `id` int(11) NOT NULL,
  `name` varchar(25) NOT NULL,
  `pnr` int(11) NOT NULL,
  `source` varchar(15) NOT NULL,
  `destination` varchar(15) NOT NULL,
  `day` varchar(15) NOT NULL,
  `arrival` time(6) NOT NULL,
  `departure` time(6) NOT NULL,
  `price2s` int(11) NOT NULL,
  `pricesl` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `display_trains`
--

INSERT INTO `display_trains` (`id`, `name`, `pnr`, `source`, `destination`, `day`, `arrival`, `departure`, `price2s`, `pricesl`) VALUES
(3, 'Adi Mmct', 1001, 'Ahmedabad', 'Nadiad', 'Monady', '04:55:00.000000', '05:32:00.000000', 90, 140),
(4, 'Adi Mas', 1002, 'Ahmedabad', 'Nadiad', 'Tuesday', '09:40:00.000000', '10:19:00.000000', 110, 145),
(5, 'Gnc Indb', 1003, 'Ahmedabad', 'Nadiad', 'Wednesday', '19:35:00.000000', '20:16:00.000000', 115, 175),
(6, 'Adi kur', 1004, 'Ahmedabad', 'Nadiad', 'Thursday', '19:00:00.000000', '19:41:00.000000', 95, 120),
(7, 'Ddr festival', 1005, 'Ahmedabad', 'Nadiad', 'Friday', '04:55:00.000000', '05:46:00.000000', 97, 122),
(8, 'Smnh Jbp', 1006, 'Ahmedabad', 'Nadiad', 'Saturday', '18:50:00.000000', '19:34:00.000000', 99, 124),
(9, 'Bhuj Ddr', 1007, 'Ahmedabad', 'Nadiad', 'Sunday', '05:30:00.000000', '06:15:00.000000', 101, 130),
(10, 'Sabarmati spl', 1008, 'Nadiad', 'Ahmedabad', 'MOnday', '23:47:00.000000', '01:10:00.000000', 106, 135),
(11, 'Brc jam', 1009, 'Nadiad', 'Ahmedabad', 'Tuesday', '16:31:00.000000', '17:30:00.000000', 109, 138),
(12, 'Ddr bkn', 1010, 'Nadiad', 'Ahmedabad', 'Wednesday', '19:59:00.000000', '21:40:00.000000', 111, 142),
(13, 'Aii festival', 1011, 'Nadiad', 'Ahmedabad', 'Thursday', '21:27:00.000000', '22:55:00.000000', 113, 144),
(14, 'Hwh Adi', 1012, 'Nadiad', 'Ahmedabad', 'Friday', '10:48:00.000000', '12:15:00.000000', 117, 148),
(15, 'Jbp somnath', 1013, 'Nadiad', 'Ahmedabad', 'Saturday', '06:42:00.000000', '08:10:00.000000', 119, 152),
(16, 'Puri Adi', 1014, 'Nadiad', 'Ahmedabad', 'Sunday', '05:01:00.000000', '06:25:00.000000', 121, 156),
(17, 'Bdts vrl', 1015, 'Surat', 'Nadiad', 'Monday', '17:40:00.000000', '20:47:00.000000', 123, 158),
(18, 'Mys Aii', 1016, 'Surat', 'Nadiad', 'Tuesday', '01:46:00.000000', '04:08:00.000000', 127, 161),
(19, 'Yor Bkn', 1017, 'Surat', 'Nadiad', 'Wednesday', '16:21:00.000000', '18:47:00.000000', 130, 162),
(20, 'Pryj Adi', 1018, 'Surat', 'Nadiad', 'Thursday', '13:55:00.000000', '16:34:00.000000', 132, 164),
(21, 'Mmct1 Adi', 1019, 'Surat', 'Nadiad', 'Friday', '13:46:00.000000', '16:40:00.000000', 134, 166),
(22, 'Hwh1 Adi', 1020, 'Surat', 'Ahmedabad', 'Saturday', '08:12:00.000000', '10:47:00.000000', 136, 168),
(23, 'Puri1 Adi', 1021, 'Surat', 'Nadiad', 'Sunday', '02:35:00.000000', '05:00:00.000000', 141, 171),
(24, 'Adi1 Mmct', 1022, 'Nadiad', 'Surat', 'Monday', '05:34:00.000000', '08:03:00.000000', 143, 173),
(25, 'Vrl1 Bdts', 1023, 'Nadiad', 'Surat', 'Tuesday', '21:05:00.000000', '00:20:00.000000', 147, 177),
(26, 'Veraval pune', 1024, 'Nadiad', 'Surat', 'Wednesday', '20:58:00.000000', '23:51:00.000000', 149, 179),
(27, 'Adi kur1', 1025, 'Nadiad', 'Surat', 'Thursday', '19:43:00.000000', '22:45:00.000000', 151, 181),
(28, 'Adi MMct2', 1026, 'Nadiad', 'Surat', 'Friday', '05:34:00.000000', '08:03:00.000000', 153, 183),
(29, 'Adi mas1', 1027, 'Nadiad', 'Surat', 'Saturday', '10:21:00.000000', '13:07:00.000000', 157, 187),
(30, 'Bhuj ddr1', 1028, 'Nadiad', 'Surat', 'Sunday', '06:17:00.000000', '09:50:00.000000', 159, 189);

-- --------------------------------------------------------

--
-- Table structure for table `django_admin_log`
--

CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext DEFAULT NULL,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) UNSIGNED NOT NULL CHECK (`action_flag` >= 0),
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `django_admin_log`
--

INSERT INTO `django_admin_log` (`id`, `action_time`, `object_id`, `object_repr`, `action_flag`, `change_message`, `content_type_id`, `user_id`) VALUES
(1, '2021-04-01 10:36:13.448329', '1', 'Trains object (1)', 1, '[{\"added\": {}}]', 8, 1),
(2, '2021-04-01 10:37:09.649604', '2', 'Trains object (2)', 1, '[{\"added\": {}}]', 8, 1),
(3, '2021-04-02 04:58:50.622065', '1', 'Trains object (1)', 2, '[{\"changed\": {\"fields\": [\"Pricesl\"]}}]', 8, 1),
(4, '2021-04-02 04:59:09.491287', '2', 'Trains object (2)', 2, '[{\"changed\": {\"fields\": [\"Pricesl\"]}}]', 8, 1),
(5, '2021-04-02 09:37:38.678043', '5', 'Tickets object (5)', 3, '', 9, 1),
(6, '2021-04-02 09:37:54.841240', '4', 'Tickets object (4)', 3, '', 9, 1),
(7, '2021-04-02 09:37:54.974088', '3', 'Tickets object (3)', 3, '', 9, 1),
(8, '2021-04-02 09:37:55.048449', '2', 'Tickets object (2)', 3, '', 9, 1),
(9, '2021-04-02 09:37:55.084457', '1', 'Tickets object (1)', 3, '', 9, 1),
(10, '2021-04-02 09:40:46.018798', '6', 'Tickets object (6)', 3, '', 9, 1),
(11, '2021-04-02 09:50:29.713569', '8', 'Tickets object (8)', 3, '', 9, 1),
(12, '2021-04-02 09:50:30.120232', '7', 'Tickets object (7)', 3, '', 9, 1),
(13, '2021-04-02 09:56:46.695001', '9', 'Tickets object (9)', 3, '', 9, 1),
(14, '2021-04-02 10:09:30.744223', '11', 'Tickets object (11)', 3, '', 9, 1),
(15, '2021-04-02 10:09:30.878245', '10', 'Tickets object (10)', 3, '', 9, 1),
(16, '2021-04-02 18:47:44.851780', '1', 'Avail object (1)', 1, '[{\"added\": {}}]', 10, 1),
(17, '2021-04-02 19:06:50.183361', '1', 'Avail object (1)', 2, '[{\"changed\": {\"fields\": [\"Seat\"]}}]', 10, 1),
(18, '2021-04-02 19:18:19.780023', '1', 'Avail object (1)', 2, '[{\"changed\": {\"fields\": [\"Seat\"]}}]', 10, 1),
(19, '2021-04-02 19:26:00.837136', '1', 'Avail object (1)', 2, '[{\"changed\": {\"fields\": [\"Seat\"]}}]', 10, 1),
(20, '2021-04-02 19:49:23.323676', '1', 'Avail object (1)', 2, '[{\"changed\": {\"fields\": [\"Seatsl\", \"Seat2s\"]}}]', 10, 1),
(21, '2021-04-03 05:20:21.271904', '1', 'Avail object (1)', 2, '[{\"changed\": {\"fields\": [\"Seatsl\", \"Seat2s\"]}}]', 10, 1),
(22, '2021-04-03 05:33:06.903983', '1', 'Avail object (1)', 2, '[{\"changed\": {\"fields\": [\"Seatsl\", \"Seat2s\"]}}]', 10, 1),
(23, '2021-04-03 05:35:22.177897', '2', 'Trains object (2)', 3, '', 8, 1),
(24, '2021-04-03 05:35:26.226068', '1', 'Trains object (1)', 3, '', 8, 1),
(25, '2021-04-03 05:35:32.251289', '1', 'Avail object (1)', 3, '', 10, 1),
(26, '2021-04-03 05:35:41.088577', '13', 'Tickets object (13)', 3, '', 9, 1),
(27, '2021-04-03 05:35:44.921307', '12', 'Tickets object (12)', 3, '', 9, 1),
(28, '2021-04-03 05:43:26.556883', '3', 'Trains object (3)', 1, '[{\"added\": {}}]', 8, 1),
(29, '2021-04-03 05:45:19.123976', '4', 'Trains object (4)', 1, '[{\"added\": {}}]', 8, 1),
(30, '2021-04-03 05:47:44.519566', '5', 'Trains object (5)', 1, '[{\"added\": {}}]', 8, 1),
(31, '2021-04-03 05:47:54.327874', '3', 'Trains object (3)', 2, '[{\"changed\": {\"fields\": [\"Pnr\"]}}]', 8, 1),
(32, '2021-04-03 05:48:01.609491', '4', 'Trains object (4)', 2, '[{\"changed\": {\"fields\": [\"Pnr\"]}}]', 8, 1),
(33, '2021-04-03 05:49:53.094107', '6', 'Trains object (6)', 1, '[{\"added\": {}}]', 8, 1),
(34, '2021-04-03 05:51:38.659050', '7', 'Trains object (7)', 1, '[{\"added\": {}}]', 8, 1),
(35, '2021-04-03 05:53:12.189180', '8', 'Trains object (8)', 1, '[{\"added\": {}}]', 8, 1),
(36, '2021-04-03 05:54:37.684873', '9', 'Trains object (9)', 1, '[{\"added\": {}}]', 8, 1),
(37, '2021-04-03 05:56:17.934175', '10', 'Trains object (10)', 1, '[{\"added\": {}}]', 8, 1),
(38, '2021-04-03 05:57:55.245777', '11', 'Trains object (11)', 1, '[{\"added\": {}}]', 8, 1),
(39, '2021-04-03 05:59:42.323793', '12', 'Trains object (12)', 1, '[{\"added\": {}}]', 8, 1),
(40, '2021-04-03 06:01:06.458714', '13', 'Trains object (13)', 1, '[{\"added\": {}}]', 8, 1),
(41, '2021-04-03 06:02:16.520215', '14', 'Trains object (14)', 1, '[{\"added\": {}}]', 8, 1),
(42, '2021-04-03 06:03:14.238775', '15', 'Trains object (15)', 1, '[{\"added\": {}}]', 8, 1),
(43, '2021-04-03 06:04:18.543756', '16', 'Trains object (16)', 1, '[{\"added\": {}}]', 8, 1),
(44, '2021-04-03 06:06:32.450227', '17', 'Trains object (17)', 1, '[{\"added\": {}}]', 8, 1),
(45, '2021-04-03 06:08:04.373220', '18', 'Trains object (18)', 1, '[{\"added\": {}}]', 8, 1),
(46, '2021-04-03 06:09:48.185823', '19', 'Trains object (19)', 1, '[{\"added\": {}}]', 8, 1),
(47, '2021-04-03 06:11:03.688450', '20', 'Trains object (20)', 1, '[{\"added\": {}}]', 8, 1),
(48, '2021-04-03 06:12:20.706391', '21', 'Trains object (21)', 1, '[{\"added\": {}}]', 8, 1),
(49, '2021-04-03 06:13:29.131470', '22', 'Trains object (22)', 1, '[{\"added\": {}}]', 8, 1),
(50, '2021-04-03 06:14:56.676184', '23', 'Trains object (23)', 1, '[{\"added\": {}}]', 8, 1),
(51, '2021-04-03 06:17:13.677399', '24', 'Trains object (24)', 1, '[{\"added\": {}}]', 8, 1),
(52, '2021-04-03 06:18:22.281848', '25', 'Trains object (25)', 1, '[{\"added\": {}}]', 8, 1),
(53, '2021-04-03 06:19:40.231241', '26', 'Trains object (26)', 1, '[{\"added\": {}}]', 8, 1),
(54, '2021-04-03 06:20:46.179301', '27', 'Trains object (27)', 1, '[{\"added\": {}}]', 8, 1),
(55, '2021-04-03 06:22:01.038730', '28', 'Trains object (28)', 1, '[{\"added\": {}}]', 8, 1),
(56, '2021-04-03 06:23:17.591550', '29', 'Trains object (29)', 1, '[{\"added\": {}}]', 8, 1),
(57, '2021-04-03 06:24:31.814475', '30', 'Trains object (30)', 1, '[{\"added\": {}}]', 8, 1),
(58, '2021-04-03 06:25:33.605001', '2', 'Avail object (2)', 1, '[{\"added\": {}}]', 10, 1),
(59, '2021-04-03 06:25:41.314257', '3', 'Avail object (3)', 1, '[{\"added\": {}}]', 10, 1),
(60, '2021-04-03 06:25:47.351166', '4', 'Avail object (4)', 1, '[{\"added\": {}}]', 10, 1),
(61, '2021-04-03 06:25:53.493618', '5', 'Avail object (5)', 1, '[{\"added\": {}}]', 10, 1),
(62, '2021-04-03 06:26:00.004222', '6', 'Avail object (6)', 1, '[{\"added\": {}}]', 10, 1),
(63, '2021-04-03 06:26:05.828246', '7', 'Avail object (7)', 1, '[{\"added\": {}}]', 10, 1),
(64, '2021-04-03 06:26:11.457773', '8', 'Avail object (8)', 1, '[{\"added\": {}}]', 10, 1),
(65, '2021-04-03 06:26:16.277658', '9', 'Avail object (9)', 1, '[{\"added\": {}}]', 10, 1),
(66, '2021-04-03 06:26:21.361090', '10', 'Avail object (10)', 1, '[{\"added\": {}}]', 10, 1),
(67, '2021-04-03 06:26:26.292775', '11', 'Avail object (11)', 1, '[{\"added\": {}}]', 10, 1),
(68, '2021-04-03 06:26:31.445950', '12', 'Avail object (12)', 1, '[{\"added\": {}}]', 10, 1),
(69, '2021-04-03 06:26:36.564524', '13', 'Avail object (13)', 1, '[{\"added\": {}}]', 10, 1),
(70, '2021-04-03 06:26:49.094664', '14', 'Avail object (14)', 1, '[{\"added\": {}}]', 10, 1),
(71, '2021-04-03 06:26:53.858544', '15', 'Avail object (15)', 1, '[{\"added\": {}}]', 10, 1),
(72, '2021-04-03 06:26:59.627052', '16', 'Avail object (16)', 1, '[{\"added\": {}}]', 10, 1),
(73, '2021-04-03 06:27:03.735081', '17', 'Avail object (17)', 1, '[{\"added\": {}}]', 10, 1),
(74, '2021-04-03 06:27:07.624554', '18', 'Avail object (18)', 1, '[{\"added\": {}}]', 10, 1),
(75, '2021-04-03 06:27:11.335187', '19', 'Avail object (19)', 1, '[{\"added\": {}}]', 10, 1),
(76, '2021-04-03 06:27:22.860092', '20', 'Avail object (20)', 1, '[{\"added\": {}}]', 10, 1),
(77, '2021-04-03 06:27:30.560103', '21', 'Avail object (21)', 1, '[{\"added\": {}}]', 10, 1),
(78, '2021-04-03 06:27:36.504994', '22', 'Avail object (22)', 1, '[{\"added\": {}}]', 10, 1),
(79, '2021-04-03 06:27:42.085548', '23', 'Avail object (23)', 1, '[{\"added\": {}}]', 10, 1),
(80, '2021-04-03 06:27:52.903994', '24', 'Avail object (24)', 1, '[{\"added\": {}}]', 10, 1),
(81, '2021-04-03 06:27:59.255528', '25', 'Avail object (25)', 1, '[{\"added\": {}}]', 10, 1),
(82, '2021-04-03 06:28:04.631584', '26', 'Avail object (26)', 1, '[{\"added\": {}}]', 10, 1),
(83, '2021-04-03 06:28:10.312527', '27', 'Avail object (27)', 1, '[{\"added\": {}}]', 10, 1),
(84, '2021-04-03 06:28:15.149133', '28', 'Avail object (28)', 1, '[{\"added\": {}}]', 10, 1),
(85, '2021-04-03 06:28:20.941346', '29', 'Avail object (29)', 1, '[{\"added\": {}}]', 10, 1);

-- --------------------------------------------------------

--
-- Table structure for table `django_content_type`
--

CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `django_content_type`
--

INSERT INTO `django_content_type` (`id`, `app_label`, `model`) VALUES
(1, 'admin', 'logentry'),
(3, 'auth', 'group'),
(2, 'auth', 'permission'),
(4, 'auth', 'user'),
(5, 'contenttypes', 'contenttype'),
(7, 'dbtestapp', 'student'),
(8, 'display', 'trains'),
(11, 'feedback', 'feedback'),
(10, 'info', 'avail'),
(9, 'info', 'tickets'),
(6, 'sessions', 'session');

-- --------------------------------------------------------

--
-- Table structure for table `django_migrations`
--

CREATE TABLE `django_migrations` (
  `id` int(11) NOT NULL,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `django_migrations`
--

INSERT INTO `django_migrations` (`id`, `app`, `name`, `applied`) VALUES
(1, 'contenttypes', '0001_initial', '2021-02-16 18:35:24.284486'),
(2, 'auth', '0001_initial', '2021-02-16 18:35:25.760548'),
(3, 'admin', '0001_initial', '2021-02-16 18:35:33.880053'),
(4, 'admin', '0002_logentry_remove_auto_add', '2021-02-16 18:35:36.485438'),
(5, 'admin', '0003_logentry_add_action_flag_choices', '2021-02-16 18:35:36.544333'),
(6, 'contenttypes', '0002_remove_content_type_name', '2021-02-16 18:35:37.319939'),
(7, 'auth', '0002_alter_permission_name_max_length', '2021-02-16 18:35:38.336833'),
(8, 'auth', '0003_alter_user_email_max_length', '2021-02-16 18:35:38.516318'),
(9, 'auth', '0004_alter_user_username_opts', '2021-02-16 18:35:38.553115'),
(10, 'auth', '0005_alter_user_last_login_null', '2021-02-16 18:35:39.453898'),
(11, 'auth', '0006_require_contenttypes_0002', '2021-02-16 18:35:39.506393'),
(12, 'auth', '0007_alter_validators_add_error_messages', '2021-02-16 18:35:39.549268'),
(13, 'auth', '0008_alter_user_username_max_length', '2021-02-16 18:35:39.810968'),
(14, 'auth', '0009_alter_user_last_name_max_length', '2021-02-16 18:35:40.020112'),
(15, 'auth', '0010_alter_group_name_max_length', '2021-02-16 18:35:40.224713'),
(16, 'auth', '0011_update_proxy_permissions', '2021-02-16 18:35:40.329376'),
(17, 'auth', '0012_alter_user_first_name_max_length', '2021-02-16 18:35:40.476606'),
(18, 'dbtestapp', '0001_initial', '2021-02-16 18:35:40.984953'),
(19, 'sessions', '0001_initial', '2021-02-16 18:35:41.244066'),
(20, 'display', '0001_initial', '2021-03-31 10:43:25.157167'),
(21, 'display', '0002_trains_price', '2021-04-01 10:17:35.323987'),
(22, 'display', '0003_auto_20210402_1027', '2021-04-02 04:57:14.047709'),
(23, 'info', '0001_initial', '2021-04-02 07:08:15.448469'),
(24, 'info', '0002_auto_20210402_1302', '2021-04-02 07:32:37.061327'),
(25, 'info', '0003_auto_20210402_1519', '2021-04-02 09:50:01.587497'),
(26, 'info', '0004_auto_20210402_1538', '2021-04-02 10:08:45.002736'),
(27, 'info', '0005_avail', '2021-04-02 18:35:52.274475'),
(28, 'info', '0006_auto_20210403_0105', '2021-04-02 19:36:29.593103'),
(29, 'feedback', '0001_initial', '2021-04-03 07:09:00.499208');

-- --------------------------------------------------------

--
-- Table structure for table `django_session`
--

CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `django_session`
--

INSERT INTO `django_session` (`session_key`, `session_data`, `expire_date`) VALUES
('himo3e9f11m7o342aagl6v2jafu49p2h', '.eJxVjMsOwiAQRf-FtSHAMJS6dO83kOExUjU0Ke3K-O_apAvd3nPOfYlA21rD1ssSpizOQovT7xYpPUrbQb5Tu80yzW1dpih3RR60y-ucy_NyuH8HlXr91gDWKetZG8eQ0GLJlNkhe4-DHRJEsIRmdACEyShW7LSHkkxmBXoU7w_CazcU:1lHlIk:sowulV6fafC2aEkvBb91cn2O8LD2JlC6XpLTvHAwiB0', '2021-03-18 10:33:50.924325'),
('zpcd5l55d0j55o5vzzllkvx306jeft4u', '.eJxVjMsOwiAQRf-FtSHAMJS6dO83kOExUjU0Ke3K-O_apAvd3nPOfYlA21rD1ssSpizOQovT7xYpPUrbQb5Tu80yzW1dpih3RR60y-ucy_NyuH8HlXr91gDWKetZG8eQ0GLJlNkhe4-DHRJEsIRmdACEyShW7LSHkkxmBXoU7w_CazcU:1lSao7:c-YMQ89zt2milU-EqxVe8TXMwLy37uIWdAAUAb01mZc', '2021-04-17 07:34:59.249506');

-- --------------------------------------------------------

--
-- Table structure for table `feedback_feedback`
--

CREATE TABLE `feedback_feedback` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `email` varchar(25) NOT NULL,
  `feedbacks` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `feedback_feedback`
--

INSERT INTO `feedback_feedback` (`id`, `name`, `email`, `feedbacks`) VALUES
(1, 'deep', 'morkerdeep11@gmail.com', 'Good');

-- --------------------------------------------------------

--
-- Table structure for table `info_avail`
--

CREATE TABLE `info_avail` (
  `id` int(11) NOT NULL,
  `pnr` varchar(15) NOT NULL,
  `seat2s` int(11) NOT NULL,
  `seatsl` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `info_avail`
--

INSERT INTO `info_avail` (`id`, `pnr`, `seat2s`, `seatsl`) VALUES
(2, '1001', 42, 40),
(3, '1002', 50, 50),
(4, '1003', 50, 50),
(5, '1004', 50, 50),
(6, '1005', 50, 50),
(7, '1006', 50, 50),
(8, '1007', 50, 50),
(9, '1008', 50, 48),
(10, '1009', 50, 50),
(11, '1010', 50, 50),
(12, '1011', 50, 50),
(13, '1012', 50, 50),
(14, '1013', 50, 50),
(15, '1014', 50, 50),
(16, '1015', 50, 50),
(17, '1016', 50, 50),
(18, '1017', 50, 49),
(19, '1018', 50, 50),
(20, '1019', 50, 50),
(21, '1020', 50, 50),
(22, '1021', 50, 50),
(23, '1022', 50, 50),
(24, '1023', 50, 50),
(25, '1024', 50, 50),
(26, '1025', 50, 50),
(27, '1026', 50, 50),
(28, '1027', 50, 50),
(29, '1028', 50, 50);

-- --------------------------------------------------------

--
-- Table structure for table `info_tickets`
--

CREATE TABLE `info_tickets` (
  `id` int(11) NOT NULL,
  `date` date NOT NULL,
  `no` int(11) NOT NULL,
  `total_price` int(11) NOT NULL,
  `ages` varchar(500) NOT NULL,
  `passangers` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `info_tickets`
--

INSERT INTO `info_tickets` (`id`, `date`, `no`, `total_price`, `ages`, `passangers`) VALUES
(14, '2021-04-06', 2, 280, '15, 19', 'arya, deep'),
(15, '2021-04-05', 1, 90, '19', 'deep'),
(16, '2021-04-05', 1, 90, '19', 'deep'),
(17, '2021-04-05', 1, 90, '19', 'deep'),
(18, '2021-04-05', 1, 90, '19', 'deep'),
(19, '2021-04-05', 1, 90, '19', 'deep'),
(20, '2021-04-05', 1, 90, '19', 'deep'),
(21, '2021-04-05', 1, 90, '19', 'deep'),
(22, '2021-04-05', 1, 90, '19', 'deep'),
(23, '2021-04-05', 2, 270, '40, 35', 'bharat, sangita'),
(24, '2021-03-30', 5, 700, '19', 'xyz'),
(25, '2021-03-30', 5, 700, '19', 'xyz'),
(26, '2021-04-07', 1, 162, '19', 'deep');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `auth_group`
--
ALTER TABLE `auth_group`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  ADD KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`);

--
-- Indexes for table `auth_permission`
--
ALTER TABLE `auth_permission`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`);

--
-- Indexes for table `auth_user`
--
ALTER TABLE `auth_user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  ADD KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`);

--
-- Indexes for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  ADD KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`);

--
-- Indexes for table `dbtestapp_student`
--
ALTER TABLE `dbtestapp_student`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `display_trains`
--
ALTER TABLE `display_trains`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  ADD KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`);

--
-- Indexes for table `django_content_type`
--
ALTER TABLE `django_content_type`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`);

--
-- Indexes for table `django_migrations`
--
ALTER TABLE `django_migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `django_session`
--
ALTER TABLE `django_session`
  ADD PRIMARY KEY (`session_key`),
  ADD KEY `django_session_expire_date_a5c62663` (`expire_date`);

--
-- Indexes for table `feedback_feedback`
--
ALTER TABLE `feedback_feedback`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `info_avail`
--
ALTER TABLE `info_avail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `info_tickets`
--
ALTER TABLE `info_tickets`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `auth_group`
--
ALTER TABLE `auth_group`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_permission`
--
ALTER TABLE `auth_permission`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `auth_user`
--
ALTER TABLE `auth_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `dbtestapp_student`
--
ALTER TABLE `dbtestapp_student`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `display_trains`
--
ALTER TABLE `display_trains`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=86;

--
-- AUTO_INCREMENT for table `django_content_type`
--
ALTER TABLE `django_content_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `django_migrations`
--
ALTER TABLE `django_migrations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `feedback_feedback`
--
ALTER TABLE `feedback_feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `info_avail`
--
ALTER TABLE `info_avail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `info_tickets`
--
ALTER TABLE `info_tickets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  ADD CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  ADD CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`);

--
-- Constraints for table `auth_permission`
--
ALTER TABLE `auth_permission`
  ADD CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`);

--
-- Constraints for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  ADD CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  ADD CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  ADD CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  ADD CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  ADD CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  ADD CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
